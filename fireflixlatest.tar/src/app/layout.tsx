import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "sonner";
import { ThemeProvider } from "next-themes";
import FloatingNav from "@/components/FloatingNav";
import GlobalContextMenuBlocker from "@/components/GlobalContextMenuBlocker";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "FireFlix - Watch Movies & TV Shows Online",
  description: "FireFlix is your ultimate destination for watching movies and TV shows online. Discover, watch, and enjoy the latest content in stunning quality.",
  keywords: ["FireFlix", "movies", "TV shows", "streaming", "watch online", "free movies"],
  authors: [{ name: "FireFlix" }],
  icons: {
    icon: "/logo.png",
  },
  openGraph: {
    title: "FireFlix - Watch Movies & TV Shows Online",
    description: "Your ultimate destination for watching movies and TV shows online in stunning quality.",
    url: "https://fireflix.com",
    siteName: "FireFlix",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "FireFlix - Watch Movies & TV Shows Online",
    description: "Your ultimate destination for watching movies and TV shows online in stunning quality.",
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange={false}
        >
          <GlobalContextMenuBlocker />
          {children}
          <Toaster />
          <FloatingNav />
        </ThemeProvider>
      </body>
    </html>
  );
}
