'use client'

import { useEffect, useState } from 'react'
import ContinueWatching from '@/components/ContinueWatchingSection'
import Navigation from '@/components/Navigation'
import HeroSection from '@/components/HeroSection'
import MovieRow from '@/components/MovieRow'
import FeaturedSpotlight from '@/components/FeaturedSpotlight'
import OriginalsSection from '@/components/OriginalsSection'
import { Film, TrendingUp, Star, Clock, Tv, Zap, Flame, Sparkles } from 'lucide-react'
import { useSettings } from '@/hooks/useSettings'

interface Movie {
  id: number
  title: string
  posterPath: string | null
  backdropPath: string | null
  overview: string
  voteAverage: number
  releaseDate: string
  genreIds: number[]
  mediaType?: string
}

export default function Home() {
  const { settings, mounted } = useSettings()
  const [trendingMovies, setTrendingMovies] = useState<Movie[]>([])
  const [popularMovies, setPopularMovies] = useState<Movie[]>([])
  const [topRatedMovies, setTopRatedMovies] = useState<Movie[]>([])
  const [nowPlayingMovies, setNowPlayingMovies] = useState<Movie[]>([])
  const [trendingTV, setTrendingTV] = useState<Movie[]>([])
  const [popularTV, setPopularTV] = useState<Movie[]>([])
  const [topRatedTV, setTopRatedTV] = useState<Movie[]>([])
  const [loading, setLoading] = useState(true)

  const TMDB_API_KEY = '7967738a03ec215c7d6d675faba9c973'
  const BASE_URL = 'https://api.themoviedb.org/3'

  useEffect(() => {
    const fetchContent = async () => {
      try {
        // Use region from settings to get region-specific content
        const region = settings.region || 'US'

        const [trendingMovieRes, popularMovieRes, topRatedMovieRes, nowPlayingRes,
              trendingTVRes, popularTVRes, topRatedTVRes] = await Promise.all([
          fetch(`${BASE_URL}/trending/movie/week?api_key=${TMDB_API_KEY}&region=${region}`),
          fetch(`${BASE_URL}/movie/popular?api_key=${TMDB_API_KEY}&region=${region}`),
          fetch(`${BASE_URL}/movie/top_rated?api_key=${TMDB_API_KEY}&region=${region}`),
          fetch(`${BASE_URL}/movie/now_playing?api_key=${TMDB_API_KEY}&region=${region}`),
          fetch(`${BASE_URL}/trending/tv/week?api_key=${TMDB_API_KEY}&region=${region}`),
          fetch(`${BASE_URL}/tv/popular?api_key=${TMDB_API_KEY}&region=${region}`),
          fetch(`${BASE_URL}/tv/top_rated?api_key=${TMDB_API_KEY}&region=${region}`)
        ])

        const [trendingMovieData, popularMovieData, topRatedMovieData, nowPlayingData,
              trendingTVData, popularTVData, topRatedTVData] = await Promise.all([
          trendingMovieRes.json(),
          popularMovieRes.json(),
          topRatedMovieRes.json(),
          nowPlayingRes.json(),
          trendingTVRes.json(),
          popularTVRes.json(),
          topRatedTVRes.json()
        ])

        const mapMovie = (m: any, type = 'movie') => ({
          id: m.id,
          title: m.title || m.name || 'Unknown',
          posterPath: m.poster_path,
          backdropPath: m.backdrop_path,
          overview: m.overview || '',
          voteAverage: m.vote_average,
          releaseDate: m.release_date || m.first_air_date || '',
          genreIds: m.genre_ids || [],
          mediaType: type
        })

        setTrendingMovies((trendingMovieData.results || []).map((m: any) => mapMovie(m, 'movie')))
        setPopularMovies((popularMovieData.results || []).map((m: any) => mapMovie(m, 'movie')))
        setTopRatedMovies((topRatedMovieData.results || []).map((m: any) => mapMovie(m, 'movie')))
        setNowPlayingMovies((nowPlayingData.results || []).map((m: any) => mapMovie(m, 'movie')))
        setTrendingTV((trendingTVData.results || []).map((m: any) => mapMovie(m, 'tv')))
        setPopularTV((popularTVData.results || []).map((m: any) => mapMovie(m, 'tv')))
        setTopRatedTV((topRatedTVData.results || []).map((m: any) => mapMovie(m, 'tv')))
      } catch (error) {
        console.error('Error fetching content:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchContent()
  }, [settings.region])

  const heroMovies = trendingMovies.slice(0, 5)

  // Define category components based on settings.categoryOrder
  const getCategoryComponent = (categoryId: string, index: number) => {
    switch (categoryId) {
      case 'nowPlaying':
        return (
          <MovieRow
            key="nowPlaying"
            title="Now Playing"
            movies={nowPlayingMovies}
            loading={loading}
            icon={<Clock className="w-5 h-5" />}
          />
        )
      case 'trending':
        return (
          <MovieRow
            key="trending"
            title="Trending Now"
            movies={trendingMovies}
            loading={loading}
            icon={<Flame className="w-5 h-5 text-orange-500" />}
          />
        )
      case 'popular':
        return (
          <MovieRow
            key="popular"
            title="Popular Movies"
            movies={popularMovies}
            loading={loading}
            icon={<Film className="w-5 h-5" />}
          />
        )
      case 'topRated':
        return (
          <MovieRow
            key="topRated"
            title="Top Rated"
            movies={topRatedMovies}
            loading={loading}
            icon={<Star className="w-5 h-5" />}
          />
        )
      case 'trendingTV':
        return (
          <MovieRow
            key="trendingTV"
            title="Trending TV Shows"
            movies={trendingTV}
            loading={loading}
            icon={<Zap className="w-5 h-5 text-yellow-500" />}
          />
        )
      case 'popularTV':
        return (
          <MovieRow
            key="popularTV"
            title="Popular TV Shows"
            movies={popularTV}
            loading={loading}
            icon={<Tv className="w-5 h-5" />}
          />
        )
      case 'topRatedTV':
        return (
          <MovieRow
            key="topRatedTV"
            title="Top Rated TV Shows"
            movies={topRatedTV}
            loading={loading}
            icon={<Sparkles className="w-5 h-5 text-purple-500" />}
          />
        )
      default:
        return null
    }
  }

  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {loading ? (
        <HeroSection movies={[]} />
      ) : (
        <HeroSection movies={heroMovies} />
      )}

      {/* Continue Watching - Only show if enabled in settings */}
      {settings.showContinueWatching && <ContinueWatching />}

      <div className={`${settings.layoutDensity === 'compact' ? 'space-y-0' : 'space-y-0'} pb-12`}>
        {settings.categoryOrder.map((categoryId, index) => {
          const categoryComponent = getCategoryComponent(categoryId, index)
          const nextIndex = index + 1

          return (
            <div key={`category-${categoryId}`}>
              {categoryComponent}

              {/* Featured Spotlight 1: After 2nd category (if enabled) */}
              {settings.showFeaturedSpotlights && nextIndex === 2 && !loading && topRatedMovies[0] && (
                <FeaturedSpotlight
                  title={topRatedMovies[0].title}
                  backdropPath={topRatedMovies[0].backdropPath}
                  voteAverage={topRatedMovies[0].voteAverage}
                  year={topRatedMovies[0].releaseDate ? new Date(topRatedMovies[0].releaseDate).getFullYear() : new Date().getFullYear()}
                  description={topRatedMovies[0].overview}
                  id={topRatedMovies[0].id}
                  mediaType={topRatedMovies[0].mediaType as 'movie' | 'tv'}
                  accentColor="bg-yellow-500"
                  gradientFrom="from-yellow-500"
                  gradientTo="to-orange-500"
                />
              )}

              {/* Featured Spotlight 2: After 4th category (if enabled) */}
              {settings.showFeaturedSpotlights && nextIndex === 4 && !loading && trendingTV[0] && (
                <FeaturedSpotlight
                  title={trendingTV[0].title}
                  backdropPath={trendingTV[0].backdropPath}
                  voteAverage={trendingTV[0].voteAverage}
                  year={trendingTV[0].releaseDate ? new Date(trendingTV[0].releaseDate).getFullYear() : new Date().getFullYear()}
                  description={trendingTV[0].overview}
                  id={trendingTV[0].id}
                  mediaType="tv"
                  accentColor="bg-purple-500"
                  gradientFrom="from-purple-500"
                  gradientTo="to-pink-500"
                />
              )}

              {/* Originals Section: After 5th category (if enabled) */}
              {settings.showOriginals && nextIndex === 5 && <OriginalsSection />}

              {/* Featured Spotlight 3: After 6th category (if enabled) */}
              {settings.showFeaturedSpotlights && nextIndex === 6 && !loading && topRatedTV[0] && (
                <FeaturedSpotlight
                  title={topRatedTV[0].title}
                  backdropPath={topRatedTV[0].backdropPath}
                  voteAverage={topRatedTV[0].voteAverage}
                  year={topRatedTV[0].releaseDate ? new Date(topRatedTV[0].releaseDate).getFullYear() : new Date().getFullYear()}
                  description={topRatedTV[0].overview}
                  id={topRatedTV[0].id}
                  mediaType="tv"
                  accentColor="bg-blue-500"
                  gradientFrom="from-blue-500"
                  gradientTo="to-cyan-500"
                />
              )}
            </div>
          )
        })}

        {/* Featured Spotlight 4: After all categories (if enabled) */}
        {settings.showFeaturedSpotlights && !loading && popularMovies[0] && (
          <FeaturedSpotlight
            title={popularMovies[0].title}
            backdropPath={popularMovies[0].backdropPath}
            voteAverage={popularMovies[0].voteAverage}
            year={popularMovies[0].releaseDate ? new Date(popularMovies[0].releaseDate).getFullYear() : new Date().getFullYear()}
            description={popularMovies[0].overview}
            id={popularMovies[0].id}
            mediaType="movie"
            accentColor="bg-red-500"
            gradientFrom="from-red-500"
            gradientTo="to-orange-500"
          />
        )}
      </div>

      <footer className="border-t border-border/50 bg-muted/30 mt-12">
        <div className="max-w-[1800px] mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <img src="/logo.png" alt="FireFlix" className="w-10 h-10 rounded-xl" />
                <span className="text-2xl font-bold">FireFlix</span>
              </div>
              <p className="text-muted-foreground max-w-md">
                Your ultimate destination for watching movies and TV shows online in stunning quality.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Browse</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Trending</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Popular</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Top Rated</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Coming Soon</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Help</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">FAQ</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Terms of Service</a></li>
              </ul>
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-border/50 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 FireFlix. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </main>
  )
}
