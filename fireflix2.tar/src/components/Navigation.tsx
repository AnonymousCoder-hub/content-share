'use client'

import { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { Search, Home, Film, TrendingUp, Star, Menu, X, User, Loader2, Calendar, Heart, Bookmark, Settings, Bell } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useSettings } from '@/hooks/useSettings'

interface SearchResult {
  id: number
  title?: string
  name?: string
  poster_path: string | null
  vote_average: number
  release_date?: string
  first_air_date?: string
  media_type: string
}

export default function Navigation() {
  const router = useRouter()
  const { settings, mounted } = useSettings()
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState<SearchResult[]>([])
  const [isSearching, setIsSearching] = useState(false)
  const [showSearchDropdown, setShowSearchDropdown] = useState(false)
  const searchDropdownRef = useRef<HTMLDivElement>(null)
  const searchTimeoutRef = useRef<NodeJS.Timeout>()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // Handle search with debounce
  useEffect(() => {
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current)
    }

    if (searchQuery.trim().length >= 2) {
      setIsSearching(true)
      searchTimeoutRef.current = setTimeout(async () => {
        try {
          const region = settings.region || 'US'
          const response = await fetch(
            `https://api.themoviedb.org/3/search/multi?api_key=7967738a03ec215c7d6d675faba9c973&query=${encodeURIComponent(searchQuery)}&region=${region}`
          )
          const data = await response.json()
          const filteredResults = (data.results || [])
            .filter((item: SearchResult) => item.media_type === 'movie' || item.media_type === 'tv')
            .slice(0, 8)
          setSearchResults(filteredResults)
          setShowSearchDropdown(true)
        } catch (error) {
          console.error('Search error:', error)
          setSearchResults([])
        } finally {
          setIsSearching(false)
        }
      }, 300)
    } else {
      setSearchResults([])
      setShowSearchDropdown(false)
    }

    return () => {
      if (searchTimeoutRef.current) {
        clearTimeout(searchTimeoutRef.current)
      }
    }
  }, [searchQuery, settings.region])

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchDropdownRef.current && !searchDropdownRef.current.contains(event.target as Node)) {
        setShowSearchDropdown(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      setShowSearchDropdown(false)
      router.push(`/search?query=${encodeURIComponent(searchQuery.trim())}`)
    }
  }

  const handleResultClick = (result: SearchResult) => {
    setShowSearchDropdown(false)
    setSearchQuery('')
    if (result.media_type === 'movie') {
      router.push(`/movie/${result.id}`)
    } else if (result.media_type === 'tv') {
      router.push(`/tv/${result.id}`)
    }
  }

  const handleNavClick = (href: string) => {
    setIsMobileMenuOpen(false)
    if (href.startsWith('/')) {
      router.push(href)
    }
  }

  const navItems = [
    { icon: Home, label: 'Home', href: '/' },
    { icon: Heart, label: 'Favourites', href: '/favourites' },
    { icon: Bookmark, label: 'Bookmarks', href: '/bookmarks' },
  ]

  const getYear = (date?: string) => {
    return date ? new Date(date).getFullYear() : 'N/A'
  }

  const getTitle = (item: SearchResult) => {
    return item.title || item.name || 'Unknown'
  }

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 overflow-x-hidden ${
        isScrolled
          ? 'bg-background/95 backdrop-blur-xl border-b border-border/50'
          : 'bg-gradient-to-b from-black/60 to-transparent'
      }`}
    >
      <div className="max-w-[1800px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2 group">
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="flex items-center space-x-2"
            >
              <img src="/logo.png" alt="FireFlix" className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl" />
            </motion.div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-foreground/80 hover:text-foreground hover:bg-white/10 active:bg-white/20 active:scale-95 transition-all duration-200"
                >
                  <item.icon className="w-4 h-4 mr-2" />
                  {item.label}
                </Button>
              </Link>
            ))}
          </div>

          {/* Right Section */}
          <div className="flex items-center space-x-2 sm:space-x-4">
            {/* Search Bar - Always Visible */}
            <div className="relative" ref={searchDropdownRef}>
              <form onSubmit={handleSearchSubmit}>
                <div className="relative group">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground group-focus-within:text-foreground transition-colors" />
                  <Input
                    type="search"
                    placeholder="Search movies & shows..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onFocus={() => searchQuery.trim().length >= 2 && setShowSearchDropdown(true)}
                    className="pl-10 pr-10 h-9 bg-white/10 border-white/10 text-foreground placeholder:text-muted-foreground/70 focus:bg-white/15 focus:border-white/20 transition-all duration-200 rounded-full w-40 sm:w-64 focus:w-72"
                  />
                  {isSearching && (
                    <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground animate-spin" />
                  )}
                  {!isSearching && searchQuery && (
                    <button
                      type="button"
                      onClick={() => {
                        setSearchQuery('')
                        setShowSearchDropdown(false)
                      }}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </form>

              {/* Search Dropdown */}
              <AnimatePresence>
                {showSearchDropdown && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                    className="absolute top-full right-0 mt-2 w-full sm:w-96 bg-card/95 backdrop-blur-xl border border-border rounded-2xl shadow-2xl overflow-hidden max-h-[500px] overflow-y-auto z-50"
                  >
                    {isSearching ? (
                      <div className="p-8 flex items-center justify-center">
                        <Loader2 className="w-6 h-6 text-muted-foreground animate-spin" />
                      </div>
                    ) : searchResults.length > 0 ? (
                      <>
                        <div className="p-3 border-b border-border/50">
                          <p className="text-xs text-muted-foreground font-medium">
                            Top Results for "{searchQuery}"
                          </p>
                        </div>
                        {searchResults.map((result) => (
                          <button
                            key={result.id}
                            onClick={() => handleResultClick(result)}
                            className="w-full p-3 hover:bg-accent transition-colors flex items-start gap-3 text-left border-b border-border/30 last:border-0"
                          >
                            <div className="flex-shrink-0 w-12 h-16 rounded-lg overflow-hidden bg-muted">
                              {result.poster_path ? (
                                <img
                                  src={`https://image.tmdb.org/t/p/w200${result.poster_path}`}
                                  alt={getTitle(result)}
                                  className="w-full h-full object-cover"
                                />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center">
                                  <Film className="w-5 h-5 text-muted-foreground/50" />
                                </div>
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <h3 className="font-medium text-sm line-clamp-1 mb-1">
                                {getTitle(result)}
                              </h3>
                              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                <Badge variant="secondary" className="h-5 px-1.5 py-0 text-[10px]">
                                  {result.media_type === 'movie' ? 'Movie' : 'TV'}
                                </Badge>
                                <span className="flex items-center gap-1">
                                  <Calendar className="w-3 h-3" />
                                  {getYear(result.release_date || result.first_air_date)}
                                </span>
                                {result.vote_average > 0 && (
                                  <span className="flex items-center gap-1">
                                    <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                                    {result.vote_average.toFixed(1)}
                                  </span>
                                )}
                              </div>
                            </div>
                          </button>
                        ))}
                        <div className="p-3 border-t border-border/50">
                          <button
                            onClick={handleSearchSubmit}
                            className="w-full text-center text-sm text-primary hover:text-primary/80 font-medium"
                          >
                            View all results for "{searchQuery}"
                          </button>
                        </div>
                      </>
                    ) : searchQuery.trim().length >= 2 ? (
                      <div className="p-8 text-center">
                        <Search className="w-12 h-12 mx-auto text-muted-foreground/50 mb-3" />
                        <p className="text-sm text-muted-foreground">No results found</p>
                      </div>
                    ) : (
                      <div className="p-6">
                        <p className="text-sm text-muted-foreground mb-3">Popular Searches</p>
                        <div className="flex flex-wrap gap-2">
                          {['Dune', 'Oppenheimer', 'Barbie', 'Batman', 'Avatar'].map((term) => (
                            <button
                              key={term}
                              onClick={() => setSearchQuery(term)}
                              className="px-3 py-1.5 bg-secondary hover:bg-accent rounded-full text-xs font-medium transition-colors"
                            >
                              {term}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Notifications Button - Only show if enabled */}
            {settings.notificationsEnabled && (
              <Link href="/notifications">
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-foreground/80 hover:text-foreground hover:bg-white/10 hover:scale-105 active:scale-95 transition-all duration-200 relative"
                  title="Notifications"
                >
                  <Bell className="w-5 h-5" />
                  <span className="absolute top-1 right-1 w-2 h-2 bg-primary rounded-full animate-pulse" />
                </Button>
              </Link>
            )}

            {/* Mobile Menu Toggle */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden text-foreground/80 hover:text-foreground hover:bg-white/10"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              <AnimatePresence mode="wait">
                {isMobileMenuOpen ? (
                  <motion.div
                    key="close"
                    initial={{ rotate: -90, opacity: 0 }}
                    animate={{ rotate: 0, opacity: 1 }}
                    exit={{ rotate: 90, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <X className="w-5 h-5" />
                  </motion.div>
                ) : (
                  <motion.div
                    key="menu"
                    initial={{ rotate: 90, opacity: 0 }}
                    animate={{ rotate: 0, opacity: 1 }}
                    exit={{ rotate: -90, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Menu className="w-5 h-5" />
                  </motion.div>
                )}
              </AnimatePresence>
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="md:hidden border-t border-border/50 bg-background/95 backdrop-blur-xl"
          >
            <div className="px-4 py-4 space-y-2">
              {navItems.map((item, index) => (
                <motion.div
                  key={item.href}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1, duration: 0.2 }}
                >
                  <button
                    onClick={() => handleNavClick(item.href)}
                    className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-accent active:bg-accent/80 transition-all duration-200 active:scale-95"
                  >
                    <item.icon className="w-5 h-5 text-foreground/70" />
                    <span className="text-foreground/90">{item.label}</span>
                  </button>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  )
}
