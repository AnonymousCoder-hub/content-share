'use client'

import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Star, Check, ChevronDown, Zap, Play, Plus, Trash2, AlertCircle } from 'lucide-react'
import CustomSourceManager, { CustomSource as CustomSourceType } from './CustomSourceManager'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'

export interface Player {
  id: string
  name: string
  getUrl: (imdbId: string, tmdbId: string, mediaType: 'movie' | 'tv', season?: number, episode?: number) => string
  useSandbox: boolean
  sandboxPermissions?: string
  isCustom?: boolean
  baseUrl?: string
}

export interface CustomSource {
  id: string
  name: string
  baseUrl: string
  useSandbox: boolean
}

// Default built-in players
const builtInPlayers: Player[] = [
  {
    id: 'ezsource',
    name: 'EZsource',
    getUrl: (imdbId) => `https://lethe399key.com/play/${imdbId}`,
    useSandbox: true,
    sandboxPermissions: "allow-scripts allow-same-origin allow-presentation allow-forms"
  },
  {
    id: 'autoembed',
    name: 'AutoEmbed',
    getUrl: (imdbId, tmdbId, mediaType, season = 1, episode = 1) => {
      if (mediaType === 'tv') {
        return `https://player.autoembed.cc/embed/tv/${imdbId}/${season}/${episode}?server=15`
      }
      return `https://player.autoembed.cc/embed/movie/${imdbId}?server=15`
    },
    useSandbox: false
  },
  {
    id: 'vidsrc',
    name: 'VidSrc',
    getUrl: (imdbId, tmdbId, mediaType, season = 1, episode = 1) => {
      if (mediaType === 'tv') {
        return `https://vidsrc.cc/v2/embed/tv/${imdbId}/${season}/${episode}`
      }
      return `https://vidsrc.cc/v2/embed/movie/${imdbId}`
    },
    useSandbox: true,
    sandboxPermissions: "allow-scripts allow-same-origin allow-presentation"
  },
  {
    id: 'rivestream',
    name: 'RiveStream',
    getUrl: (imdbId, tmdbId, mediaType, season = 1, episode = 1) => {
      if (mediaType === 'tv') {
        return `https://rivestream.org/embed?type=tv&id=${tmdbId}&season=${season}&episode=${episode}`
      }
      return `https://rivestream.org/embed?type=movie&id=${tmdbId}`
    },
    useSandbox: false
  }
]

// Function to create a player from custom source
export const createPlayerFromCustomSource = (customSource: CustomSource): Player => {
  return {
    id: customSource.id,
    name: customSource.name,
    getUrl: (imdbId, tmdbId, mediaType, season = 1, episode = 1) => {
      let url = customSource.baseUrl
        .replace('{tmdb_id}', tmdbId)
        .replace('{imdb_id}', imdbId)
        .replace('{season}', season.toString())
        .replace('{episode}', episode.toString())
      return url
    },
    useSandbox: customSource.useSandbox,
    sandboxPermissions: customSource.useSandbox ? "allow-scripts allow-same-origin allow-presentation" : undefined,
    isCustom: true,
    baseUrl: customSource.baseUrl
  }
}

interface PlayerSelectorProps {
  imdbId: string
  tmdbId: string
  mediaType: 'movie' | 'tv'
  season?: number
  episode?: number
  onPlayerChange: (player: Player) => void
}

export default function PlayerSelector({
  imdbId,
  tmdbId,
  mediaType,
  season = 1,
  episode = 1,
  onPlayerChange
}: PlayerSelectorProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [isCustomSourceOpen, setIsCustomSourceOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [playerToDelete, setPlayerToDelete] = useState<Player | null>(null)
  const dropdownRef = useRef<HTMLDivElement>(null)

  // State for all players (built-in + custom) - load from localStorage on mount
  const [players, setPlayers] = useState<Player[]>(() => {
    try {
      const savedSources = localStorage.getItem('customSources')
      if (savedSources) {
        const customSources: CustomSourceType[] = JSON.parse(savedSources)
        const customPlayers = customSources.map(createPlayerFromCustomSource)
        return [...builtInPlayers, ...customPlayers]
      }
    } catch (error) {
      console.error('Error loading custom sources from localStorage:', error)
    }
    return builtInPlayers
  })

  // Initialize with saved default player or fallback to ezsource
  const [selectedPlayer, setSelectedPlayer] = useState<Player>(() => {
    const savedDefaultPlayer = typeof window !== 'undefined' ? localStorage.getItem('defaultPlayerId') : null
    const player = builtInPlayers.find((p) => p.id === savedDefaultPlayer)
    return player || builtInPlayers[0]
  })
  const [defaultPlayerId, setDefaultPlayerId] = useState<string>(() => {
    return typeof window !== 'undefined' ? localStorage.getItem('defaultPlayerId') || 'ezsource' : 'ezsource'
  })

  const hasInitializedRef = useRef(false)

  // Notify parent of initial player (only once on mount)
  useEffect(() => {
    if (!hasInitializedRef.current) {
      hasInitializedRef.current = true
      onPlayerChange(selectedPlayer)
    }
  }, [])

  // Reload custom sources when dropdown opens
  useEffect(() => {
    if (!isOpen) return

    const updatePlayers = () => {
      try {
        const savedSources = localStorage.getItem('customSources')
        if (savedSources) {
          const customSources: CustomSourceType[] = JSON.parse(savedSources)
          const customPlayers = customSources.map(createPlayerFromCustomSource)
          const allPlayers = [...builtInPlayers, ...customPlayers]

          // Update selected player if it was deleted (check against all players)
          const currentStillExists = allPlayers.find(p => p.id === selectedPlayer.id)
          if (!currentStillExists) {
            const newPlayer = builtInPlayers[0]
            setSelectedPlayer(newPlayer)
            onPlayerChange(newPlayer)
          }

          setPlayers(allPlayers)
        } else {
          setPlayers(builtInPlayers)
        }
      } catch (error) {
        console.error('Error reloading custom sources:', error)
      }
    }

    // Use setTimeout to avoid synchronous setState in effect
    setTimeout(updatePlayers, 0)
  }, [isOpen])

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside)
      return () => document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [isOpen])

  const handlePlayerSelect = (player: Player) => {
    setSelectedPlayer(player)
    onPlayerChange(player)
    setIsOpen(false)
  }

  const handleSetDefault = (e: React.MouseEvent, playerId: string) => {
    e.stopPropagation()
    setDefaultPlayerId(playerId)
    localStorage.setItem('defaultPlayerId', playerId)
  }

  const handleDeleteClick = (player: Player, e: React.MouseEvent) => {
    e.stopPropagation()
    setPlayerToDelete(player)
    setDeleteDialogOpen(true)
  }

  const handleDeleteConfirm = () => {
    if (!playerToDelete) return

    // Remove from localStorage
    try {
      const savedSources = localStorage.getItem('customSources')
      if (savedSources) {
        const customSources: CustomSourceType[] = JSON.parse(savedSources)
        const updated = customSources.filter(s => s.id !== playerToDelete.id)
        localStorage.setItem('customSources', JSON.stringify(updated))
      }
    } catch (error) {
      console.error('Error removing custom source from localStorage:', error)
    }

    // Update state
    setPlayers(players.filter(p => p.id !== playerToDelete.id))

    // If deleted player was selected, select first available player
    if (selectedPlayer.id === playerToDelete.id) {
      const newSelected = players[0]
      setSelectedPlayer(newSelected)
      onPlayerChange(newSelected)
    }

    // If deleted player was default, reset to ezsource
    if (defaultPlayerId === playerToDelete.id) {
      setDefaultPlayerId('ezsource')
      localStorage.setItem('defaultPlayerId', 'ezsource')
    }

    setDeleteDialogOpen(false)
    setPlayerToDelete(null)
  }

  const handleCustomSourceAdd = (customSource: CustomSourceType) => {
    // Check for duplicate base URLs (optional - prevents adding same source twice)
    try {
      const savedSources = localStorage.getItem('customSources')
      const existingSources: CustomSourceType[] = savedSources ? JSON.parse(savedSources) : []
      const isDuplicate = existingSources.some(s => s.baseUrl === customSource.baseUrl)

      if (isDuplicate) {
        console.warn('A source with this URL already exists')
        return
      }

      // Save to localStorage
      const updatedSources = [...existingSources, customSource]
      localStorage.setItem('customSources', JSON.stringify(updatedSources))

      // Add to players list
      const newPlayer = createPlayerFromCustomSource(customSource)
      setPlayers([...players, newPlayer])

      // Select the new player and notify parent
      setSelectedPlayer(newPlayer)
      onPlayerChange(newPlayer)

      // Close the modal
      setIsCustomSourceOpen(false)
    } catch (error) {
      console.error('Error saving custom source to localStorage:', error)
    }
  }

  return (
    <div className="relative" ref={dropdownRef}>
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-black/60 hover:bg-black/70 backdrop-blur-md text-white border border-white/20 rounded-lg px-4 py-2 flex items-center gap-2 text-sm font-medium transition-all"
      >
        <Play className="w-4 h-4" />
        <span>{selectedPlayer.name}</span>
        <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </Button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="absolute right-0 top-full mt-2 w-56 bg-black/95 backdrop-blur-xl border border-white/10 rounded-xl overflow-hidden shadow-2xl z-50"
          >
            <div className="p-2 space-y-1">
              {players.map((player) => (
                <div
                  key={player.id}
                  className="relative group"
                >
                  <button
                    onClick={() => handlePlayerSelect(player)}
                    className="w-full flex items-center justify-between px-3 py-3 text-white hover:bg-white/10 transition-all duration-200 rounded-lg pr-10"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full transition-colors ${
                        selectedPlayer.id === player.id ? 'bg-green-500' : 'bg-white/30 group-hover:bg-white/50'
                      }`} />
                      <Star
                        className={`w-3.5 h-3.5 transition-all duration-200 ${
                          defaultPlayerId === player.id
                            ? 'fill-yellow-400 text-yellow-400 scale-110'
                            : 'text-white/30 group-hover:text-white/50 hover:text-yellow-400/70'
                        }`}
                        onClick={(e) => {
                          e.stopPropagation()
                          handleSetDefault(e, player.id)
                        }}
                      />
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{player.name}</span>
                        {player.isCustom && (
                          <Zap className="w-3 h-3 text-yellow-400" />
                        )}
                      </div>
                    </div>
                    <Check
                      className={`w-4 h-4 transition-all duration-200 ${
                        selectedPlayer.id === player.id ? 'text-green-500 scale-100' : 'opacity-0 scale-75'
                      }`}
                    />
                  </button>

                  {/* Delete button for custom sources */}
                  {player.isCustom && (
                    <button
                      onClick={(e) => handleDeleteClick(player, e)}
                      className="absolute top-1/2 -translate-y-1/2 right-2 p-1.5 text-red-400/80 hover:text-red-400 hover:bg-red-500/20 rounded-lg transition-all"
                      title="Remove this source"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}

              {/* Add Source Button */}
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  setIsCustomSourceOpen(true)
                }}
                className="w-full flex items-center justify-center gap-2 px-3 py-3 mt-2 text-purple-400 hover:text-purple-300 hover:bg-purple-500/10 transition-all duration-200 rounded-lg group border border-dashed border-white/20 hover:border-purple-500/50"
              >
                <Plus className="w-4 h-4 group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium">Add Custom Source</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Custom Source Manager */}
      <CustomSourceManager
        isOpen={isCustomSourceOpen}
        onClose={() => setIsCustomSourceOpen(false)}
        onSourceAdd={handleCustomSourceAdd}
      />

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="bg-gray-900 border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                <AlertCircle className="w-5 h-5 text-red-500" />
              </div>
              <span>Delete Source</span>
            </DialogTitle>
            <DialogDescription className="text-white/70">
              Are you sure you want to delete "{playerToDelete?.name}"? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setDeleteDialogOpen(false)
                setPlayerToDelete(null)
              }}
              className="border-white/20 text-white hover:bg-white/10"
            >
              Cancel
            </Button>
            <Button
              onClick={handleDeleteConfirm}
              className="bg-red-600 hover:bg-red-700 text-white border-0"
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
